﻿internal class Cicle
{
}